#!/bin/sh
# Start the harness with the bundled glibc and libraries.
d=$(dirname "$(readlink -f "$0")")
exec "$d/lib/ld-linux-aarch64.so.1" --library-path "$d/lib" "$d/flexstack-bench-vanetza" "$@"
