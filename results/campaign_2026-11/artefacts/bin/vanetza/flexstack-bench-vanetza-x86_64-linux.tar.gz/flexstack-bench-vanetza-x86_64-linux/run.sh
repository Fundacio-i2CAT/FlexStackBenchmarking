#!/bin/sh
# Start the harness with the bundled glibc and libraries.
d=$(dirname "$(readlink -f "$0")")
exec "$d/lib/ld-linux-x86-64.so.2" --library-path "$d/lib" "$d/flexstack-bench-vanetza" "$@"
